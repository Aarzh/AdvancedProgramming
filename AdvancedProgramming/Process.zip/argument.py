import sys

n1=int(sys.argv[1])#GETS THE NUMBER AS PARAMETER AND TRANSFORM IT TO INT
n2 = int(sys.argv[1])#GETS THE NUMBER AS PARAMETER AND TRANSFORM IT TO INT

highest = max(n1, n2)#GETS THE highest NUMBER
sys.exit(highest)#RETURN THE VALUE
